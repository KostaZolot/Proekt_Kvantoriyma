import datetime
import sqlalchemy
from .db_session import SqlAlchemyBase


class Register_from_compani(SqlAlchemyBase):
    __tablename__ = 'sotrydnik_register'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    surname = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    Ochectvo = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    nomer_telefona = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    created_date_1 = sqlalchemy.Column(sqlalchemy.DateTime, default=datetime.datetime.now)

    def __repr__(self):
        return f'<Register_from_compani> {self.name} {self.surname} {self.Ochectvo} {self.nomer_telefona}'
