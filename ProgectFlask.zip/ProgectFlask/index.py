# сделать pip freeze > requirements.txt
import sqlite3
from flask import Flask, render_template, redirect, make_response, request
from flask import jsonify
from flask_login import LoginManager, login_user, login_required, logout_user

from forms.user import RegisterForm, LoginForm
from forms.register_from_compani import RegisterForm_compani
from data.users import User
from data.RegisterFormСompani import Register_from_compani
from data import db_session
import numpy as np

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

login_manager = LoginManager()
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)


@app.errorhandler(400)
def bad_request(_):
    return make_response(jsonify({'error': 'Bad Request'}), 400)


def main():
    db_session.global_init("db/blogs.db")
    app.run(port=8080, host='127.0.0.1')


def get_db_connection():
    conn = sqlite3.connect('prodykt.db')
    conn.row_factory = sqlite3.Row
    return conn


def get_db_connection2():
    conn = sqlite3.connect('db/blogs.db')
    conn.row_factory = sqlite3.Row
    return conn


@app.route('/')
def index():
    return render_template('base_3.html')


@app.route('/pokypka', methods=['POST'])
def doit():
    a = []
    b = np.arange(0, 10000001)
    prodykt = request.form['prodykt']
    prodykt1 = request.form['prodykt']
    cens = request.form['cens']
    kartink = request.form['kartink']
    conn = get_db_connection()
    cur = conn.cursor()
    post = cur.execute("""SELECT * FROM cena """).fetchall()
    for c in post:
        a.append(c["id_prodykt"])
    if prodykt in a:
        prodykt1 += f" {b[len(a)]}"
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""INSERT INTO cena(id_prodykt, cen_prodykt, kertink, prodykt_if_dl_del) VALUES(?, ?, ?, ?)""",
                    (prodykt, cens, kartink, prodykt1)).fetchall()
        conn.commit()
        return render_template('base_3.html')
    else:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""INSERT INTO cena(id_prodykt, cen_prodykt, kertink, prodykt_if_dl_del) VALUES(?, ?, ?, ?)""",
                    (prodykt, cens, kartink, prodykt1)).fetchall()
        conn.commit()
        return render_template('base_3.html')


@app.route('/bonys', methods=['POST'])
def bonys():
    bonys = 0
    polzovatil = request.form['polzovatil']
    conn = get_db_connection2()
    posts = conn.execute("""SELECT * FROM users WHERE name = ? """, (polzovatil,)).fetchall()
    for i in posts:
        bonys = int(i["bonys_db"])
    return render_template('bonnusiii.html', bonys=bonys)


@app.route('/karzina1', methods=['POST'])
def delit():
    if request.method == "POST":

        # удаление
        prodykt_del1 = request.form["prodykt_del1"]
        print(prodykt_del1)
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""DELETE FROM cena WHERE prodykt_if_dl_del = ?""", (prodykt_del1,)).fetchall()
        conn.commit()

        # прорисовка
        polzovatil = request.form['polzovatil']
        conn = get_db_connection2()
        posts = conn.execute("""SELECT * FROM users WHERE name = ?""", (polzovatil,)).fetchall()
        for i in posts:
            bonys_polzovatil = i["bonys_db"]
            obh_cena = 0
            bonys = 0
            obh_cena2 = 0
            list = ["деньги", "бонусы"]

            conn = get_db_connection()
            posts = conn.execute('SELECT * FROM cena').fetchall()
            for c in posts:
                obh_cena += c['cen_prodykt']
            conn.close()

            conn = get_db_connection()
            postss = conn.execute('SELECT * FROM cena').fetchall()
            for g in postss:
                obh_cena2 += int(g['cen_prodykt'])
                bonys = obh_cena2 - (90 * obh_cena2 // 100)
            conn.close()

            return render_template('karzina.html', posts=posts, obh_cena=obh_cena, bonys=bonys,
                                   bonys_polzovatil=bonys_polzovatil, option=list)


@app.route('/karzina2', methods=['POST'])
def oform_zakaz():
    global bonys_polzovatil
    if request.method == "POST":
        bonys = 0
        obh_cena = 0
        list = ["деньги", "бонусы"]
        bonys_db = request.form['bonys_db']
        polzovatil = request.form['polzovatil']
        oplat = request.form['oplat']
        # проверка способа оплаты
        if oplat == "деньги":
            # отчистка заказа после оформления
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute("""DELETE FROM cena""").fetchall()
            conn.commit()

            # начисление бонусов + проверка если балы вообще
            conn = get_db_connection2()
            posts = conn.execute("""SELECT * FROM users WHERE name = ? """, (polzovatil,)).fetchall()
            for i in posts:
                if int(i["bonys_db"]) > 0:
                    bonys_db = int(bonys_db) + int(i["bonys_db"])
                    bonys_polzovatil = bonys_db
            conn = get_db_connection2()
            cur = conn.cursor()
            cur.execute("""UPDATE users SET bonys_db = ? WHERE name = ? """, (bonys_db, polzovatil)).fetchall()
            conn.commit()
            return render_template('karzina.html', obh_cena=obh_cena, bonys=bonys, bonys_polzovatil=bonys_polzovatil, option=list)
        elif oplat == "бонусы":
            # берём цену товаров
            polzovatil = request.form['polzovatil']
            obh_cena = 0
            conn = get_db_connection()
            posts = conn.execute('SELECT * FROM cena').fetchall()
            for i in posts:
                obh_cena += i['cen_prodykt']
            # берём количество бонусов
            conn = get_db_connection2()
            posts = conn.execute("""SELECT * FROM users WHERE name = ? """, (polzovatil,)).fetchall()
            for i in posts:
                if int(i["bonys_db"]) > 0:
                    bonys = int(i["bonys_db"])
            if (obh_cena // 2) > bonys:
                obh_cena = 0
                bonys = 0
                conn = get_db_connection()
                posts = conn.execute('SELECT * FROM cena').fetchall()
                for i in posts:
                    obh_cena += i['cen_prodykt']
                    bonys = obh_cena - (90 * obh_cena // 100)
                conn.close()
                polzovatil = request.form['polzovatil']
                conn = get_db_connection2()
                dl_cena = conn.execute("""SELECT * FROM users WHERE name = ?""", (polzovatil,)).fetchall()
                for i in dl_cena:
                    bonys_polzovatil = i["bonys_db"]
                malo = "У вас не достаточно бонусов попробуйте другой способ оплаты"
                return render_template('karzina.html', malo=malo, posts=posts, obh_cena=obh_cena, bonys=bonys,
                                       bonys_polzovatil=bonys_polzovatil, option=list)
            if (obh_cena // 2) <= bonys:
                obh_cena = 0
                bonys = 0
                obh_cena_1 = 0
                conn = get_db_connection()
                posts = conn.execute('SELECT * FROM cena').fetchall()
                for ic in posts:
                    obh_cena_1 += ic['cen_prodykt']

                polzovatil = request.form['polzovatil']
                conn = get_db_connection()
                cur = conn.cursor()
                cur.execute("""DELETE FROM cena""").fetchall()
                conn.commit()

                conn = get_db_connection2()
                posts = conn.execute("""SELECT * FROM users WHERE name = ?""", (polzovatil,)).fetchall()
                for i in posts:
                    bonys_polzovatil = i["bonys_db"] - (obh_cena_1 // 2)
                polzovatil = request.form['polzovatil']
                conn = get_db_connection2()
                cur = conn.cursor()
                cur.execute("""UPDATE users SET bonys_db = ? WHERE name = ? """,
                            (bonys_polzovatil, polzovatil)).fetchall()
                conn.commit()
                return render_template('karzina.html', obh_cena=obh_cena, bonys=bonys,
                                       bonys_polzovatil=bonys_polzovatil, option=list)
        else:
            polzovatil = request.form['polzovatil']
            if polzovatil == "":
                return render_template('karzina.html')
            else:
                yps = "Способ оплаты введён не верно"
                obh_cena = 0
                bonys = 0
                polzovatil = request.form['polzovatil']
                conn = get_db_connection2()
                posts = conn.execute("""SELECT * FROM users WHERE name = ?""", (polzovatil,)).fetchall()
                for i in posts:
                    bonys_polzovatil = i["bonys_db"]
                    conn = get_db_connection()
                    posts = conn.execute('SELECT * FROM cena').fetchall()
                    for c in posts:
                        obh_cena += c['cen_prodykt']
                        bonys = obh_cena - (90 * obh_cena // 100)
                    conn.close()
                    return render_template('karzina.html', posts=posts, obh_cena=obh_cena, bonys=bonys,
                                           bonys_polzovatil=bonys_polzovatil, yps=yps)


@app.route('/karzina', methods=['POST'])
def karzina():
    # первая прорисовка
    polzovatil = request.form['polzovatil']
    if polzovatil == "":
        return render_template('karzina.html')
    else:
        obh_cena = 0
        bonys = 0
        list = ["деньги", "бонусы"]
        polzovatil = request.form['polzovatil']
        conn = get_db_connection2()
        posts = conn.execute("""SELECT * FROM users WHERE name = ?""", (polzovatil,)).fetchall()
        for i in posts:
            bonys_polzovatil = i["bonys_db"]
            conn = get_db_connection()
            posts = conn.execute('SELECT * FROM cena').fetchall()
            for c in posts:
                obh_cena += c['cen_prodykt']
                bonys = obh_cena - (90 * obh_cena // 100)
            conn.close()
            return render_template('karzina.html', posts=posts, obh_cena=obh_cena, bonys=bonys,
                                   bonys_polzovatil=bonys_polzovatil, option=list)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if len(form.password.data) <= 6:
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пароль должен быть больше 6 символов")
        if not any(map(str.isupper, form.password.data)):
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пароль должен содержать хотябы одну заглавную букву")
        s = str(form.email.data)
        j = ["gmail.com", "mail.ru", "yandex.ru"]
        a = s.rpartition('@')[2]
        if a not in j:
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Имал введён неверно")
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пользователь с таким Емейлом уже существует")
        if db_sess.query(User).filter(User.name == form.name.data).first():
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пользователь с таким именем уже существует")
        user = User(
            name=form.name.data,
            email=form.email.data,
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/kompani_register',  methods=['GET', 'POST'])
def kompani_register():
    form = RegisterForm_compani()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        if db_sess.query(Register_from_compani).filter(Register_from_compani.name == form.name.data).first() and \
                db_sess.query(Register_from_compani).filter(Register_from_compani.surname == form.surname.data).first() and \
                db_sess.query(Register_from_compani).filter(Register_from_compani.Ochectvo == form.Ochectvo.data).first() and \
                db_sess.query(Register_from_compani).filter(Register_from_compani.nomer_telefona == form.nomer_telefona.data).first():
            return render_template("kompani_register.html", message1="Вы уже отправляли форму, в течение двух дней вас пригласят на собеседование.", form=form)
        s = str(form.nomer_telefona.data)
        if (len(s[2:]) == 9 and s[:2] == "+7") or (len(s[1:]) == 9 and s[:1] == "8"):
            user2 = Register_from_compani(
                name=form.name.data,
                surname=form.surname.data,
                Ochectvo=form.Ochectvo.data,
                nomer_telefona=form.nomer_telefona.data
            )
            db_sess.add(user2)
            db_sess.commit()
            return render_template("kompani_register.html", message2="Форма отправлена.", form=form)
        else:
            return render_template("kompani_register.html", message3="В номере телефона допущена ошибка.", form=form)
    return render_template("kompani_register.html", form=form)


@app.route('/O_nas')
def O_nas():
    return render_template("O_nas.html")


@app.route('/kontact')
def kontact():
    return render_template("kontact.html")


@app.route('/vakansii')
def vakansii():
    return render_template("vakansii.html")


if __name__ == "__main__":
    main()
