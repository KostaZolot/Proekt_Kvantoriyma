from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, EmailField

from wtforms.validators import DataRequired


class RegisterForm_compani(FlaskForm):
    name = EmailField('Имя', validators=[DataRequired()])
    surname = StringField('Фамилия', validators=[DataRequired()])
    Ochectvo = StringField('Отчество', validators=[DataRequired()])
    nomer_telefona = StringField('Номер телефона', validators=[DataRequired()])
    submit = SubmitField('Отправить')
